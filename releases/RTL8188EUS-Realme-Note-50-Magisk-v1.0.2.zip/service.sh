#!/system/bin/sh

MODDIR=${0%/*}
LOG=/data/adb/rtl8188eu-boot.log

exec >> "$LOG" 2>&1

echo
echo "===== RTL8188EU BOOT SERVICE ====="
date

if [ -d /sys/module/8188eu ]; then
    echo "8188eu is already loaded."
    exit 0
fi

COUNT=0

while [ ! -d /sys/module/cfg80211 ]; do
    COUNT=$((COUNT + 1))

    if [ "$COUNT" -ge 60 ]; then
        echo "ERROR: cfg80211 did not become available."
        exit 1
    fi

    sleep 2
done

echo "cfg80211 is available."
echo "Loading RTL8188EU..."

insmod "$MODDIR/8188eu.ko"

RESULT=$?

if [ "$RESULT" -eq 0 ]; then
    echo "SUCCESS: RTL8188EU loaded."
else
    echo "ERROR: insmod failed with status $RESULT."
fi

exit "$RESULT"
