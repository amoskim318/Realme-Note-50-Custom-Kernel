ui_print "- Realme Note 50 RTL8188EUS Driver"

DEVICE_MODEL="$(getprop ro.product.model)"
if [ "$DEVICE_MODEL" != "RMX3834" ]; then
    abort "! Unsupported device: $DEVICE_MODEL"
fi

DEVICE_ABI="$(getprop ro.product.cpu.abi)"
if [ "$DEVICE_ABI" != "arm64-v8a" ]; then
    abort "! Unsupported architecture: $DEVICE_ABI"
fi

[ -f "$MODPATH/8188eu.ko" ] || abort "! Driver file is missing."
[ -f "$MODPATH/service.sh" ] || abort "! Boot service is missing."

set_perm "$MODPATH/8188eu.ko" 0 0 0644
set_perm "$MODPATH/module.prop" 0 0 0644
set_perm "$MODPATH/service.sh" 0 0 0755

ui_print "- Device checks passed."
ui_print "- Module files installed."
ui_print "- Reboot to load the driver."
